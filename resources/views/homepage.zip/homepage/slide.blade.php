
@php
$title='title_'.trans('systems.lang');
$description='description_'.trans('systems.lang')
@endphp
<section id="content">

    <div class="banner-slider bg-slider banner-slider2 parallax-slider">
        <div class="wrap-item" data-pagination="false" data-navigation="true" data-transition="fade" data-autoplay="true" data-itemscustom="[[0,1]]">




             @foreach($data['slides'] as $slide)
             <div class="item-slider item-slider2">
                <div class="banner-thumb">
                    <a href="#">
                        <img src="{{URL::asset('public/homeslider/slide1.jpg')}}" alt="{{$slide->alt}}" />
                    </a>
                </div>
                <div class="banner-info text-center">
                    <div class="img-info animated" data-animated="flipInX">
                        <img src="{{URL::asset('public/homeslider/'.$slide->image_path)}}" alt="{{$slide->alt}}" />
                    </div>
                    <div class="text-info animated" data-animated="bounceInUp">
                        <h2 class="title30 color paci-font">{{$slide->$title}}</h2>
                        <h2 class="color2 font-bold text-uppercase title30">{{$slide->$description}}</h2>
                        <div class="banner-button">
                            <a href="#contact-us" class="btn-arrow color style2">{{trans('contactus.contact')}}</a>

                        </div>
                    </div>
                </div>

             </div>
            @endforeach





        </div>
    </div>

