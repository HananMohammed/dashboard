@include('homepage.inc.header')
@include('homepage.inc.nave')
@include('homepage.slide')
@include('homepage.aboutus')
@include('homepage.proudict')
@include('homepage.news')

@include('homepage.certificates')
@include('homepage.contactus')
@yield('homecontent')

@include('homepage.inc.footr')
