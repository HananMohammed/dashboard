
</section>
@php
    $about='about_'.trans('systems.lang');
    $address='address_'.trans('systems.lang');

@endphp
<footer id="footer">
    <div class="footer2 box-parallax">
        <div class="container">
            <div class="main-footer2">
                <div class="row">
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="footer-box2">
                            <h2 class="title18 font-bold color">{{trans('about.about')}}</h2>
                            <p class="desc white">
                                {{$data['about'][0]->$about}}
                            </p>
                            <br>

                            @if($data['qrcode'][0]->show === 1)
                            <div class="foter-imagep mb-3">

                                <img src="{{URL::asset('public/Qrcode/'.$data['qrcode'][0]->image_path)}}" alt="" width="100%" height="100%">
                            </div>
                            @endif

                        </div>

                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="footer-box2">
                            <h2 class="title18 font-bold color">{{trans('address.address')}}</h2>
                            <div class="contact-footer2">
                                <p class="desc white"><span class="color"><i class="fa fa-map-marker" aria-hidden="true"></i></span>{{$data['address'][0]->$address}}</p>
                                <p class="desc white"><span class="color"><i class="fa fa-phone" aria-hidden="true">

									</i></span><a class=" text-white desc white" href="tel:01001460292">{{$data['phone'][0]->phone}}</a></p>
                                <p class="desc white"><span class="color">
										<i class="fa fa-envelope" aria-hidden="true">

										</i></span><a class=" text-white desc white" href="mailto:info@wbs-eg.com"> {{$data['email'][0]->mail}}</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="footer-box2">
                            <h2 class="title18 font-bold color">{{trans('address.subscribe')}}</h2>
{{--                            <p class="white">Stay tune for updates</p>--}}
                            <form action="{{route('subscriber.store')}}" method="post" class="email-form2">
                                @csrf
                                <input onblur="if (this.value=='') this.value = this.defaultValue" onfocus="if (this.value==this.defaultValue) this.value = ''" value="{{trans('contactus.entermail')}}" name="mail" type="text">
                                <input type="submit" value="submit">
                            </form>
                        </div>
                        <div class="social-network footer-box2">
                            <h2 class="title18 font-bold color">{{trans('contactus.contactwith')}}</h2>

                            @foreach($data['social'] as $icon)
                            <a href="{{$icon->link}}" target="_blank" class="float-shadow social">{!! $icon->socailIcon->icon !!}</a>
                           @endforeach
                            </div>
                    </div>
                </div>
            </div>
            <!-- End Main Footer -->
            <div class="logo-footer2 text-center">
                <a href="#" class="pulse"><img src="{{URL::asset('public/images/logo1.png')}}" alt=""></a>
            </div>
            <div class="bottom-footer2 text-center">
                <ul class="menu-footer2 list-inline-block">
                    <li><a class="white" href="{{route('homepage')}}">{{trans('webnav.home')}}</a></li>
                    <li><a class="white" href="#about-us">{{trans('webnav.about')}}</a></li>
                    <li><a class="white" href="#product">{{trans('webnav.Products')}}</a></li>
                    <li><a class="white" href="seasons.html">{{trans('webnav.seasons')}}</a></li>
                    <li><a class="white" href="#news">{{trans('webnav.news')}}</a></li>
                    <li><a class="white" href="#certificates">{{trans('webnav.certificates')}}</a></li>
                    <li >
                        <a class="white" href="#contact-us">{{trans('webnav.contactuS')}}</a>

                    </li>
                    <li><a class="white" href="{{route('lang',[trans('nav.langval')])}}">{{trans('nav.lang')}}</a></li>

                </ul>
                <p class="copyright2 desc white">Will Be Seen © 2019. All Rights Reserved.</p>
                <p class="design2 desc white">Design by <a href="#" class="color">Z-Line</a></p>
            </div>
        </div>
    </div>
</footer>

<a href="#" class="scroll-top round active">
    <i class="fa fa-angle-double-up"></i>
</a>
<a class="text-dark" href="#" tabindex="0" style="  position: fixed!important;
	z-index: 1000!important;
	right: 60px!important;
	bottom: 10px!important;
	width: 40px!important;
	height: 40px!important;
	background: #45bf61!important;
	color: white!important;
	text-align: center!important;
	line-height: 39px!important;
	border-radius: 50%!important;
	font-size: 18px">
    <i class="fa fa-whatsapp"></i>
</a>
<a class="text-dark" href="#" tabindex="0" style="  position: fixed!important;
		z-index: 1000!important;
		right: 110px!important;
		bottom: 10px!important;
		width: 40px!important;
		height: 40px!important;
		background: #45bf61!important;
		color: white!important;
		text-align: center!important;
		line-height: 39px!important;
		border-radius: 50%!important;
		font-size: 18px">
    <i class="fa fa-weixin"></i>
</a>

</div>
<script type="text/javascript" src="{{URL::asset('js/libs/jquery-3.2.1.min.js')}}"></script>
{{--<script type="text/javascript" src="{{URL::asset('js/libs/bootstrap.min.js')}}"></script>--}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script type="text/javascript" src="{{URL::asset('js/libs/jquery.fancybox.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('js/libs/jquery-ui.min.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('js/libs/owl.carousel.min.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('js/libs/jquery.jcarousellite.min.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('js/libs/jquery.elevatezoom.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('js/libs/jquery.mCustomScrollbar.min.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('js/libs/slick.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('js/libs/popup.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('js/libs/timecircles.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('js/libs/wow.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('js/theme.js')}}"></script>

</body>
</html>