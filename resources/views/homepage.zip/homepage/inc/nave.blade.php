<header id="header">
    <div class="header">

        <!-- End Top Header -->
        <div class="main-header2 ">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 ">
                        <div class="logo logo2 pull-left ">
                            <!-- <a href="#"><img src="images/home/home1/logo1.png" alt="" /></a> -->

                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- End Main Header -->
        <div class="nav-header2 bg-color header-ontop fixed-ontop">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <nav class="main-nav main-nav2 pull-left">
                            <ul>
                                <li class="current-menu-item menu-item-has-children"><a href="{{route('homepage')}}">{{trans('webnav.home')}}</a>

                                </li>
                                <li class="menu-item-has-children has-mega-menu"><a href="#about-us">{{trans('webnav.about')}}</a>

                                </li>
                                <li><a href="#product">{{trans('webnav.Products')}}</a></li>
                                <li><a href="{{route('season')}}">{{trans('webnav.seasons')}}</a></li>
                                <li><a href="#news">{{trans('webnav.news')}}</a></li>
                                <li><a href="#certificates">{{trans('webnav.certificates')}}</a></li>
                                <li class="menu-item-has-children">
                                    <a href="#contact-us">{{trans('webnav.contactuS')}}</a>

                                </li>
                                <li><a href="{{route('lang',[trans('nav.langval')])}}">{{trans('nav.lang')}}</a></li>
                            </ul>
                            <a href="#" class="toggle-mobile-menu"><span></span></a>
                        </nav>
                        <div class="top-social pull-right">

                            <a href="#"><img src="{{URL::asset('public/images/logo1.png')}}" alt="" class="logop"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Nav Header -->
    </div>
</header>
