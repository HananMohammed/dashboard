<!DOCTYPE HTML>

<html lang="en-US">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="Fruit Shop is new Html theme that we have designed to help you transform your store into a beautiful online showroom. This is a fully responsive Html theme, with multiple versions for homepage and multiple templates for sub pages as well" />
    <meta name="keywords" content="Fruit,7uptheme" />
    <meta name="robots" content="noodp,index,follow" />
    <meta name='revisit-after' content='1 days' />
    <title>Fruit Shop | Home Style 2</title>
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/font-awesome.min.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/ionicons.min.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/bootstrap.min.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/bootstrap-theme.min.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/jquery.fancybox.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/jquery-ui.min.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/owl.carousel.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/owl.transitions.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/jquery.mCustomScrollbar.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/owl.theme.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/slick.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/animate.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/libs/hover.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/color2.css')}}" media="all"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/style.css')}}" media="all"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/responsive.css')}}" media="all"/>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('css/browser.css')}}" media="all"/>
   <style>
       .social{
           color:white;
           font-size: 28px;
       }
   </style>
@if (session()->get('locale')=='ar'||session()->get('locale')==null)
     <link rel="stylesheet" type="text/css" href="{{URL::asset('css/rtl.css')}}" media="all"/>
@endif
</head>
<body class="preload">
<div class="wrap">