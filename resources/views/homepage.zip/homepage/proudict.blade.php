
@php
    $name='name_'.trans('systems.lang');
    $newsD='news_'.trans('systems.lang');
    $slug='slug_'.trans('systems.lang');
@endphp
<div class="deal-box2" id="product">
    <div class="title-deal-box2 white bg-color">
        <h2 class="title30 paci-font" style="    color: #45bf61;"> {{trans('products.willbe')}}</h2>
        <h2 class="title30 text-uppercase font-bold" style="    color: #b05b0a;">{{trans('products.ourpro')}}</h2>
    </div>

    <div class="deal-product2">
        <div class="container">
            <div class="deal-slider2 product-slider">
                <div class="wrap-item" data-pagination="false" data-navigation="true" data-itemscustom="[[0,1],[560,2],[990,3]]">
                   @foreach($data['products'] as $product)
                    <div class="item-product item-deal-product2 text-center">
                        <div class="product-thumb">

                            <a href="" class="product-thumb-link zoomout-thumb">
                                <img src="{{URL::asset('public/products').'/'.json_decode($product->images,true)[0]}}" alt="">
                                <img src="{{URL::asset('public/products').'/'.json_decode($product->images,true)[1]}}" alt="">
                            </a>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title"><a href="detail.html">{{$product->$name}} </a></h3>
                            <div class="product-extra-link">
                                <a href="{{route('singelProduct',[trans('products.products'),$product->id,$product->$slug])}}" class="addcart-link">{{trans('products.det')}}</a>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>

        </div>
    </div>
    <div class="deal-countdown2">

        <div class="banner-button">
            <a href="{{route('foo')}}" class="btn-arrow color style2">{{trans('products.allproducts')}}</a>

        </div>
    </div>
</div>