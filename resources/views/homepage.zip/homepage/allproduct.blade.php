@include('homepage.inc.header')
@include('homepage.inc.nave')
@php
    $title='title_'.trans('systems.lang');
    $newsD='news_'.trans('systems.lang');

    $name='name_'.trans('systems.lang');
    $newsD='news_'.trans('systems.lang');
    $slug='slug_'.trans('systems.lang');
@endphp

<section id="content">
    <div class="container">
        <div class="shop-banner banner-adv line-scale zoom-image">
            <a href="#" class="adv-thumb-link"><img src="{{URL::asset('css/img/banner-detail.jpg')}}" alt="" /></a>
            <div class="banner-info">
                <h2 class="title30 color">{{trans('products.allproducts')}}</h2>
                <div class="bread-crumb white"><a href="{{route('homepage')}}" class="white">{{trans('webnav.home')}}</a>
                    <span>{{trans('products.allproducts')}} </span></div>
            </div>
        </div>
        <!-- ENd Banner -->

    </div>
</section>
<section>
    <div class="container">
        <div class="row">
            @foreach($data['products'] as $product)
            <div class="col-md-4 col-sm-12">
                <div class="item-product item-product-grid text-center">
                    <div class="product-thumb">
                        <a href="  detail.html" class="product-thumb-link rotate-thumb">
                            <img src="{{URL::asset('public/products').'/'.json_decode($product->images,true)[0]}}" alt="">
                            <img src="{{URL::asset('public/products').'/'.json_decode($product->images,true)[1]}}" alt="">
                        </a>
                    </div>
                    <div class="product-info">
                        <h3 class="product-title"><a href="  detail.html">{{$product->$name}}</a></h3>

                        <div class="product-rate">
                            <div class="product-rating" style="width:100%"></div>
                        </div>
                        <div class="product-extra-link">
                            <a href="{{route('singelProduct',[trans('products.products'),$product->id,$product->$slug])}}" class="addcart-link">{{trans('products.det')}}</a>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach

        </div>
    </div>
</section>
@include('homepage.inc.footr')