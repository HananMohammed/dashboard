
<div class="why-choise box-parallax" id="contact-us" style="padding: 100px;margin-bottom: 0px;background-image: url({{URL::asset('css/img/prl1.jpg')}});">
    <div class="container">
        <div class="choise-title text-center wow zoomIn" style="visibility: visible; animation-name: zoomIn;">
            <h2 class="title30 paci-font color">{{trans('contactus.comname')}}</h2>
            <h2 class="title30 font-bold text-uppercase white">{{trans('contactus.contact')}}</h2>
        </div>
        <div class="list-service2">
            <div class="row">
                <div class="col-md-6 col-sm-6 ">
                    <div class="item-service1 table wow fadeInRight"
                         style="visibility: visible; animation-name: fadeInRight;">
                        <form id="contact-form" method="post" action="{{route('phpmail.index')}}">
                            @csrf
                            <div class="farm-contact-form">

                                <div class="single-inputc">
                                    <input id="name" name="name" placeholder="Name*" required="">
                                    @if($errors->has('name'))
                                        {{--                                                {{dd($errors->get('about_certificates_ar')[0])}}--}}
                                        <span class="error">{{ $errors->get('name')[0] }}</span>
                                    @endif
                                </div>
                                <div class="single-inputc">
                                    <input id="email_address"  name="email_address" placeholder="Email*" required="" type="email">
                                    @if($errors->has('email_address'))
                                        {{--                                                {{dd($errors->get('about_certificates_ar')[0])}}--}}
                                        <span class="error">{{ $errors->get('email_address')[0] }}</span>
                                    @endif
                                </div>
                                <div class="single-inputc">
                                    <input id="phone_number" name="phone_number" placeholder="Phone">
                                    @if($errors->has('phone_number'))
                                        {{--                                                {{dd($errors->get('about_certificates_ar')[0])}}--}}
                                        <span class="error">{{ $errors->get('phone_number')[0] }}</span>
                                    @endif
                                </div>

                                <div class="text-area">
                                    <textarea id="message" name="message" placeholder="Message ..."></textarea>
                                    @if($errors->has('message'))
                                        {{--                                                {{dd($errors->get('about_certificates_ar')[0])}}--}}
                                        <span class="error">{{ $errors->get('message')[0] }}</span>
                                    @endif
                                </div>
                                <div class="single-submit banner-button">
                                    <input id="submit" name="submit" type="submit" value="Sent Now" class="btn-arrow bg-color style2">

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-6">
                    <div class="item-service1 table wow fadeInRight" style="visibility: visible; animation-name: fadeInRight;">
                        <div class="service-icon">
                            <a target="_blank" href="mailto:ahmed@wbs-eg.com,h.hussein@wbs-eg.com"><i class="fa fa-envelope"></i></a>
                        </div>
                        <div class="service-info">
                            <h3 class="title18"><a target="_blank" href="mailto:ahmed@wbs-eg.com,h.hussein@wbs-eg.com" class="white">{{trans('mail.mail')}}</a></h3>
{{--                            <a class=" text-white desc white" href="mailto:h.hussein@wbs-eg.com">--}}
{{--                                h.hussein@wbs-eg.com </a>--}}
{{--                            <br>--}}
{{--                            <a class=" text-white desc white "--}}
{{--                               href="mailto:ahmed@wbs-eg.com"> ahmed@wbs-eg.com</a>--}}
{{--                            <br>--}}
{{--                            <a class=" text-white desc white" href="mailto:foda@wbs-eg.com	"> foda@wbs-eg.com </a>--}}

                        </div>
                    </div>
                    <div class="item-service1 table wow fadeInRight" style="visibility: visible; animation-name: fadeInRight;">
                        <div class="service-icon">
                            <a href="#"><i class="fa fa-volume-control-phone"></i></a>
                        </div>
                        <div class="service-info">
                            <h3 class="title18"><a href="#" class="white">{{trans('phone.phone')}}</a></h3>

                            @foreach($data['phone'] as $phone)
                            <a class=" text-white desc white" href="tel:{{$phone->phone}}">{{$phone->phone}}</a>
                            <br>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="fruit-top wow slideInLeft" style="visibility: visible; animation-name: slideInLeft;"><img src="{{URL::asset('css/img/fruit-top.png')}}" alt=""></div>
    </div>
</div>