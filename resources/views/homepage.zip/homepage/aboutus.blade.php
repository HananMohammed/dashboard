
@php
    $about='about_'.trans('systems.lang');
    $mission='mission_'.trans('systems.lang');
    $vission='vission_'.trans('systems.lang');
@endphp
<div class="container" id="about-us">
    <div class="fruit-list-cat">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="item-fruit-cat1">
                    <h2 class="title18 color2 text-uppercase font-bold text-center">{{trans('about.about')}}</h2>
                    <div class="title18 line-space color text-center"><i class="fa fa-pagelines"></i></div>
                    <ul class="list-none cat-menu2">
                        <li><a >{{$data['about'][0]->$about}}</a></li>


                    </ul>

                    <div class="cat-menu-img"><img src="{{URL::asset('public/images/home/home2/menu1.png')}}" alt="" /></div>
                </div>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="item-fruit-cat1 item-active item-center">
                    <h2 class="title18 color2 text-uppercase font-bold text-center">{{trans('mission.mission')}}</h2>
                    <div class="title18 line-space color text-center"><i class="fa fa-pagelines"></i></div>
                    <ul class="list-none cat-menu2">
                        <li class="">

                            <h2 class="title18 color2 text-uppercase font-bold text-center paddm">{{trans('mission.missionw')}} </h2>

                            <a href="#" class=" ">  {{$data['mission'][0]->$mission}}.</a></li>
                        <li>
                            <h2 class="title18 color2 text-uppercase font-bold text-center paddm"> {{trans('mission.vision')}}</h2>
                            <a href="#">  {{$data['mission'][0]->$vission}}.</a></li>

                    </ul>

                    <div class="cat-menu-img"><img src="{{URL::asset('public/images/home/home2/menu3.png')}}" alt=""/></div>
                </div>
            </div>

        </div>
    </div>

</div>